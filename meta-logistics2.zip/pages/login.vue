<template lang="html">
  <div>
    <div class="padding-top"></div>
    2343242343 adsad3
  </div>
</template>
<script>
export default {};
</script>
<style lang=""></style>

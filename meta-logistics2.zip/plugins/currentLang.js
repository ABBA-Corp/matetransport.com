// plugins/<function-name>.js
import Vue from "vue";
Vue.prototype.$currentLang = () => {
  //...
  console.log("looooooog");
};

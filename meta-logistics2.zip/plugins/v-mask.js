import VueTheMask from "vue-the-mask";
import Vue from "vue";
Vue.use(VueTheMask);

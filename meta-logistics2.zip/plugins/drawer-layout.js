import Vue from 'vue'
import DrawerLayout from 'vue-drawer-layout'
 
Vue.use(DrawerLayout)

import Chat from "vue-beautiful-chat";
import Vue from "vue";

Vue.use(Chat);

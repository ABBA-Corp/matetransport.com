export default {
  welcome: 'Welcome'
}
import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _b29f2f46 = () => interopDefault(import('..\\pages\\about-us.vue' /* webpackChunkName: "pages/about-us" */))
const _0e03727e = () => interopDefault(import('..\\pages\\all-news.vue' /* webpackChunkName: "pages/all-news" */))
const _7b42bba9 = () => interopDefault(import('..\\pages\\inner-news.vue' /* webpackChunkName: "pages/inner-news" */))
const _77448443 = () => interopDefault(import('..\\pages\\location-map.vue' /* webpackChunkName: "pages/location-map" */))
const _188e9efa = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _4ee6fbe3 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _428e57d7 = () => interopDefault(import('..\\pages\\calculator\\choice-tarif.vue' /* webpackChunkName: "pages/calculator/choice-tarif" */))
const _2323caea = () => interopDefault(import('..\\pages\\calculator\\delivery-details.vue' /* webpackChunkName: "pages/calculator/delivery-details" */))
const _3e4549f8 = () => interopDefault(import('..\\pages\\calculator\\transport.vue' /* webpackChunkName: "pages/calculator/transport" */))
const _4ffb3dd9 = () => interopDefault(import('..\\pages\\service\\_index.vue' /* webpackChunkName: "pages/service/_index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about-us",
    component: _b29f2f46,
    name: "about-us___en"
  }, {
    path: "/all-news",
    component: _0e03727e,
    name: "all-news___en"
  }, {
    path: "/inner-news",
    component: _7b42bba9,
    name: "inner-news___en"
  }, {
    path: "/location-map",
    component: _77448443,
    name: "location-map___en"
  }, {
    path: "/login",
    component: _188e9efa,
    name: "login___en"
  }, {
    path: "/ru",
    component: _4ee6fbe3,
    name: "index___ru"
  }, {
    path: "/calculator/choice-tarif",
    component: _428e57d7,
    name: "calculator-choice-tarif___en"
  }, {
    path: "/calculator/delivery-details",
    component: _2323caea,
    name: "calculator-delivery-details___en"
  }, {
    path: "/calculator/transport",
    component: _3e4549f8,
    name: "calculator-transport___en"
  }, {
    path: "/ru/about-us",
    component: _b29f2f46,
    name: "about-us___ru"
  }, {
    path: "/ru/all-news",
    component: _0e03727e,
    name: "all-news___ru"
  }, {
    path: "/ru/inner-news",
    component: _7b42bba9,
    name: "inner-news___ru"
  }, {
    path: "/ru/location-map",
    component: _77448443,
    name: "location-map___ru"
  }, {
    path: "/ru/login",
    component: _188e9efa,
    name: "login___ru"
  }, {
    path: "/ru/calculator/choice-tarif",
    component: _428e57d7,
    name: "calculator-choice-tarif___ru"
  }, {
    path: "/ru/calculator/delivery-details",
    component: _2323caea,
    name: "calculator-delivery-details___ru"
  }, {
    path: "/ru/calculator/transport",
    component: _3e4549f8,
    name: "calculator-transport___ru"
  }, {
    path: "/ru/service/:index",
    component: _4ffb3dd9,
    name: "service___ru"
  }, {
    path: "/service/:index",
    component: _4ffb3dd9,
    name: "service___en"
  }, {
    path: "/",
    component: _4ee6fbe3,
    name: "index___en"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}

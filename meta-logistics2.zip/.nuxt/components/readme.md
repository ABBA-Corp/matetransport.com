# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<AboutLogisticComp>` | `<about-logistic-comp>` (components/AboutLogisticComp.vue)
- `<AboutUs>` | `<about-us>` (components/AboutUs.vue)
- `<Banner>` | `<banner>` (components/Banner.vue)
- `<Carousel>` | `<carousel>` (components/carousel.vue)
- `<Chat>` | `<chat>` (components/Chat.vue)
- `<CoverageMap>` | `<coverage-map>` (components/CoverageMap.vue)
- `<LastNews>` | `<last-news>` (components/LastNews.vue)
- `<Loading>` | `<loading>` (components/loading.vue)
- `<LogisticCompany>` | `<logistic-company>` (components/LogisticCompany.vue)
- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<Partners>` | `<partners>` (components/Partners.vue)
- `<PartnersCarousel>` | `<partners-carousel>` (components/PartnersCarousel.vue)
- `<Title>` | `<title>` (components/Title.vue)
- `<TitleSmall>` | `<title-small>` (components/TitleSmall.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
- `<CalculatorInfoItems>` | `<calculator-info-items>` (components/calculator/calculatorInfoItems.vue)
- `<CalculatorStep1>` | `<calculator-step1>` (components/calculator/calculatorStep1.vue)
- `<CalculatorStep2>` | `<calculator-step2>` (components/calculator/calculatorStep2.vue)
- `<CalculatorStep3>` | `<calculator-step3>` (components/calculator/calculatorStep3.vue)
- `<CardsAboutLogisticCard>` | `<cards-about-logistic-card>` (components/cards/AboutLogisticCard.vue)
- `<CardsEmployeeCard>` | `<cards-employee-card>` (components/cards/EmployeeCard.vue)
- `<CardsLocationMapCard>` | `<cards-location-map-card>` (components/cards/LocationMapCard.vue)
- `<CardsLogisticCompCard>` | `<cards-logistic-comp-card>` (components/cards/LogisticCompCard.vue)
- `<CardsLogisticsServicesCard>` | `<cards-logistics-services-card>` (components/cards/LogisticsServicesCard.vue)
- `<CardsNewsCard>` | `<cards-news-card>` (components/cards/NewsCard.vue)
- `<CardsPartnersCard>` | `<cards-partners-card>` (components/cards/PartnersCard.vue)
- `<CardsServiceApplicationCard>` | `<cards-service-application-card>` (components/cards/ServiceApplicationCard.vue)
- `<BannerStepForm>` | `<banner-step-form>` (components/Banner/StepForm.vue)
- `<LayoutFooter>` | `<layout-footer>` (components/layout/Footer.vue)
- `<LayoutHeader>` | `<layout-header>` (components/layout/Header.vue)
- `<LayoutTextCarousel>` | `<layout-text-carousel>` (components/layout/TextCarousel.vue)
- `<LogisticsServices>` | `<logistics-services>` (components/LogisticsServices/LogisticsServices.vue)
- `<LogisticsServicesCarousel>` | `<logistics-services-carousel>` (components/LogisticsServices/LogisticsServicesCarousel.vue)

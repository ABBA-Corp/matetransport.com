export { default as AboutLogisticComp } from '../..\\components\\AboutLogisticComp.vue'
export { default as AboutUs } from '../..\\components\\AboutUs.vue'
export { default as Banner } from '../..\\components\\Banner.vue'
export { default as Carousel } from '../..\\components\\carousel.vue'
export { default as Chat } from '../..\\components\\Chat.vue'
export { default as CoverageMap } from '../..\\components\\CoverageMap.vue'
export { default as LastNews } from '../..\\components\\LastNews.vue'
export { default as Loading } from '../..\\components\\loading.vue'
export { default as LogisticCompany } from '../..\\components\\LogisticCompany.vue'
export { default as NuxtLogo } from '../..\\components\\NuxtLogo.vue'
export { default as Partners } from '../..\\components\\Partners.vue'
export { default as PartnersCarousel } from '../..\\components\\PartnersCarousel.vue'
export { default as Title } from '../..\\components\\Title.vue'
export { default as TitleSmall } from '../..\\components\\TitleSmall.vue'
export { default as Tutorial } from '../..\\components\\Tutorial.vue'
export { default as CalculatorInfoItems } from '../..\\components\\calculator\\calculatorInfoItems.vue'
export { default as CalculatorStep1 } from '../..\\components\\calculator\\calculatorStep1.vue'
export { default as CalculatorStep2 } from '../..\\components\\calculator\\calculatorStep2.vue'
export { default as CalculatorStep3 } from '../..\\components\\calculator\\calculatorStep3.vue'
export { default as CardsAboutLogisticCard } from '../..\\components\\cards\\AboutLogisticCard.vue'
export { default as CardsEmployeeCard } from '../..\\components\\cards\\EmployeeCard.vue'
export { default as CardsLocationMapCard } from '../..\\components\\cards\\LocationMapCard.vue'
export { default as CardsLogisticCompCard } from '../..\\components\\cards\\LogisticCompCard.vue'
export { default as CardsLogisticsServicesCard } from '../..\\components\\cards\\LogisticsServicesCard.vue'
export { default as CardsNewsCard } from '../..\\components\\cards\\NewsCard.vue'
export { default as CardsPartnersCard } from '../..\\components\\cards\\PartnersCard.vue'
export { default as CardsServiceApplicationCard } from '../..\\components\\cards\\ServiceApplicationCard.vue'
export { default as BannerStepForm } from '../..\\components\\Banner\\StepForm.vue'
export { default as LayoutFooter } from '../..\\components\\layout\\Footer.vue'
export { default as LayoutHeader } from '../..\\components\\layout\\Header.vue'
export { default as LayoutTextCarousel } from '../..\\components\\layout\\TextCarousel.vue'
export { default as LogisticsServices } from '../..\\components\\LogisticsServices\\LogisticsServices.vue'
export { default as LogisticsServicesCarousel } from '../..\\components\\LogisticsServices\\LogisticsServicesCarousel.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}

export default [
  {
    code: "en",
    file: "en-US.js",
  },
  {
    code: "fr",
    file: "fr-FR.js",
  },
];

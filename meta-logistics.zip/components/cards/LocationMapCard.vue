<template lang="html">
  <div class="location-map-card">
    <div class="lm-map">
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2995.6359508726446!2d69.33234131492554!3d41.33852900698645!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38aef48a8ed4d0e9%3A0x3772abeffc72e7b8!2z0KPQvdC40LLQtdGA0YHQuNGC0LXRgiDQmNC90YXQsA!5e0!3m2!1sru!2s!4v1674815269297!5m2!1sru!2s"
        width="100%"
        height="300"
        style="border: 0;"
        allowfullscreen=""
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"
      ></iframe>
    </div>
    <div class="lm-body">
      <h2 class="lm-title">
        New York
      </h2>
      <h6 class="lm-area">Tochka B</h6>
      <div class="lm-text">
        <p>
          Ship a Car, Inc. delivers superior shipping service to people
          relocating their vehicles, businesses moving their general freight
          and/or transporting heavy haul equipment as well as volume relocation
          services for dealers and corporations. SAC is an experienced transport
          broker with direct access to the largest network of carriers. One
          simple call does it all. When you choose Ship A Car, we deliver not
          only your vehicle and/or freight, but peace of mind as well.
        </p>
        <p>
          Contact a Ship A Car transport coordinator now at (866) 821-4555 for
          direct vehicle transport service to/from any residential or business
          location in the city of New York.Ship a Car, Inc. delivers superior
          shipping service to people relocating their vehicles, businesses
          moving their general freight and/or transporting heavy haul equipment
          as well as volume relocation services for dealers and corporations.
          SAC is an experienced transport broker with direct access to the
          largest network of carriers. One simple call does it all. When you
          choose Ship A Car, we deliver not only your vehicle and/or freight,
          but peace of mind
        </p>
      </div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style lang=""></style>

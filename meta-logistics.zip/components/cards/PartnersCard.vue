<template lang="html">
  <div class="partners-card">
    <div class="partners-grid">
      <div class="partners-avatar">
        <img src="../../assets/images/Rectangle 23905.png" alt="" />
      </div>
      <div class="partners-body">
        <div class="partners-title">
          <h3>Gillette</h3>
        </div>
        <div class="partners-text">
          <p>
            We coordinate all shipments through a large network of licensed Auto
            Shipping Carriers nationwide.
          </p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style lang=""></style>

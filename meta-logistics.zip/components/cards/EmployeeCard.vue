<template lang="html">
  <div class="employee-card">
    <img
      class="employee-bg"
      src="../../assets/images/employee-img.png"
      alt=""
    />
    <div class="employee-card-avatar">
      <img src="../../assets/images/Ellipse 102.png" alt="" />
    </div>
    <div class="">
      <h1 class="employee-card-name">Садулла Кобилжонов</h1>
      <p class="employee-card-position">Director of Mate logistics</p>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style lang=""></style>

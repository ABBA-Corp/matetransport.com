<template lang="html">
  <div class="service-app-card">
  <div class="flex-container">
    <div class="da-card-icon">
      <div class="circle">
        <div>
          1
        </div>
      </div>
    </div>
    <div class="da-card-body">
      <h4>Application form</h4>
      <p>
        Ship a Car, Inc. delivers superior shipping service to people relocating
        their vehicles, businesses moving their general freight and/or
        transporting heavy haul equipment as well as volume relocation services
        for dealers and corporations. SAC is an experienced transport broker
      </p>
    </div>
  </div>
    <div class="da-card-mobile-text">
      <p>
        Ship a Car, Inc. delivers superior shipping service to people relocating
        their vehicles, businesses moving their general freight and/or
        transporting heavy haul equipment as well as volume relocation services
        for dealers and corporations. SAC is an experienced transport broker
      </p>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style lang=""></style>
